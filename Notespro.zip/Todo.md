# Todo

* Encryption
* Ability to add media in notes
* Favourite notes feature
* Pin and unpin notes to the top
